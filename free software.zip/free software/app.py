from flask import Flask, render_template, request, redirect, url_for, flash, abort, session
from flask import Flask, render_template, request, redirect, url_for, flash, session, abort
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from functools import wraps
import os

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('is_admin'):
            abort(403)
        return f(*args, **kwargs)
    return decorated_function

app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///software_portal.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128))
    is_admin = db.Column(db.Boolean, default=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Software(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50), nullable=False)
    license = db.Column(db.String(50), nullable=False)
    version = db.Column(db.String(20))
    website = db.Column(db.String(200))
    download_link = db.Column(db.String(200))
    date_added = db.Column(db.DateTime, default=datetime.utcnow)



@app.route('/')
def index():
    softwares = Software.query.order_by(Software.date_added.desc()).all()
    return render_template('index.html', softwares=softwares)

@app.route('/software/<int:id>')
def software_detail(id):
    software = Software.query.get_or_404(id)
    return render_template('software_detail.html', software=software)

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        user = User.query.filter_by(username=request.form['username']).first()
        if user and user.is_admin and user.check_password(request.form['password']):
            session['is_admin'] = True
            flash('Logged in successfully!', 'success')
            return redirect(url_for('manage_software'))
        flash('Invalid username or password', 'error')
    return render_template('admin/login.html')

@app.route('/admin/logout')
@admin_required
def admin_logout():
    session.pop('is_admin', None)
    flash('Logged out successfully!', 'success')
    return redirect(url_for('index'))

@app.route('/admin/add_software', methods=['GET', 'POST'])
@admin_required
def add_software():
    if request.method == 'POST':
        software = Software(
            name=request.form['name'],
            description=request.form['description'],
            category=request.form['category'],
            license=request.form['license'],
            version=request.form['version'],
            website=request.form['website'],
            download_link=request.form['download_link']
        )
        db.session.add(software)
        db.session.commit()
        flash('Software added successfully!', 'success')
        return redirect(url_for('manage_software'))
    return render_template('admin/add_software.html')





@app.route('/admin/software')
@admin_required
def manage_software():
    softwares = Software.query.all()
    return render_template('admin/software.html', softwares=softwares)

@app.route('/admin/software/<int:id>/delete', methods=['POST'])
@admin_required
def delete_software(id):
    software = Software.query.get_or_404(id)
    db.session.delete(software)
    db.session.commit()
    flash('Software deleted successfully!', 'success')
    return redirect(url_for('manage_software'))

@app.route('/search')
def search():
    query = request.args.get('q', '')
    if query:
        search_term = f'%{query}%'
        softwares = Software.query.filter(
            db.or_(
                Software.name.ilike(search_term),
                Software.description.ilike(search_term),
                Software.category.ilike(search_term)
            )
        ).all()
    else:
        softwares = Software.query.all()
    return render_template('index.html', softwares=softwares)

@app.errorhandler(403)
def forbidden_error(error):
    return render_template('errors/403.html'), 403

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        # Create admin user if not exists
        admin = User.query.filter_by(username='admin').first()
        if not admin:
            admin = User(username='admin', email='admin@example.com', is_admin=True)
            admin.set_password('admin')
            db.session.add(admin)
            db.session.commit()
    app.run(debug=True)